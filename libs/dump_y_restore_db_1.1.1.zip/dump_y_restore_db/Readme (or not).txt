Scripts de Dump, Download y Restore una base de datos.

Soporte y Updaters: http://insidephp.sytes.net
email: insidephp@gmail.com

Versi�n 1.1.1 del 18 de Marzo de 2005